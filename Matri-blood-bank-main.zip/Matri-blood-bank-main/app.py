from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mail import Mail, Message
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or 'your-secret-key-here'  # Use environment variable for production

# Database configuration
DATABASE = os.path.join(app.instance_path, 'bloodbank.db')

# Email configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME') or '2002dhruba@gmail.com'
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD') or 'your-email-password-here'
app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER') or '2002dhruba@gmail.com'

mail = Mail(app)

# Initialize database
def init_db():
    os.makedirs(app.instance_path, exist_ok=True)
    with app.app_context():
        db = get_db()
        
        # Create tables if they don't exist
        db.execute('''
            CREATE TABLE IF NOT EXISTS admin (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                full_name TEXT,
                email TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        db.execute('''
            CREATE TABLE IF NOT EXISTS donors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                phone TEXT NOT NULL,
                blood_type TEXT NOT NULL,
                address TEXT NOT NULL,
                last_donation_date TEXT,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        db.execute('''
            CREATE TABLE IF NOT EXISTS volunteers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                phone TEXT NOT NULL,
                skills TEXT,
                availability TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        db.execute('''
            CREATE TABLE IF NOT EXISTS blood_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_name TEXT NOT NULL,
                hospital TEXT NOT NULL,
                blood_type TEXT NOT NULL,
                units INTEGER NOT NULL,
                urgency TEXT NOT NULL,
                contact_name TEXT NOT NULL,
                contact_phone TEXT NOT NULL,
                contact_email TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        db.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                subject TEXT NOT NULL,
                message TEXT NOT NULL,
                status TEXT DEFAULT 'unread',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        db.execute('''
            CREATE TABLE IF NOT EXISTS blood_inventory (
                blood_type TEXT PRIMARY KEY,
                units_available INTEGER NOT NULL DEFAULT 0
            )
        ''')
        
        # Create default admin if none exists
        admin = db.execute('SELECT * FROM admin LIMIT 1').fetchone()
        if not admin:
            hashed_password = generate_password_hash('admin123')  # Change this in production
            db.execute(
                'INSERT INTO admin (username, password, full_name, email) VALUES (?, ?, ?, ?)',
                ('admin', hashed_password, 'System Admin', 'admin@matribloodbank.com')
            )
        db.commit()

def get_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")  # Enable foreign key constraints
    return db

# Decorator for admin-only routes
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            flash('Please log in to access this page', 'error')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

# Helper function for sending emails
def send_email(subject, recipient, body):
    try:
        msg = Message(subject, recipients=[recipient], body=body)
        mail.send(msg)
        return True
    except Exception as e:
        app.logger.error(f"Failed to send email: {str(e)}")
        return False

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/blood_request')
def blood_request():
    return render_template('blood_request.html')

@app.route('/donor')
def donor():
    return render_template('donor.html')

@app.route('/volunteer')
def volunteer():
    return render_template('volunteer.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        subject = request.form.get('subject', '').strip()
        message = request.form.get('message', '').strip()
        
        if not all([name, email, subject, message]):
            flash('All fields are required', 'error')
            return redirect(url_for('contact'))
        
        try:
            db = get_db()
            db.execute(
                'INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)',
                (name, email, subject, message)
            )
            db.commit()
            
            # Send email notification
            email_body = f"Name: {name}\nEmail: {email}\nSubject: {subject}\nMessage: {message}"
            send_email(f"New Contact Message: {subject}", app.config['MAIL_DEFAULT_SENDER'], email_body)
            
            flash('Your message has been sent successfully!', 'success')
        except Exception as e:
            db.rollback()
            app.logger.error(f"Error saving contact message: {str(e)}")
            flash('An error occurred while sending your message', 'error')
        finally:
            db.close()
        
        return redirect(url_for('contact'))
    
    return render_template('contact.html')

@app.route('/appointment', methods=['GET', 'POST'])
def appointment():
    if request.method == 'POST':
        form_type = request.form.get('form_type')
        
        try:
            db = get_db()
            
            if form_type == 'donor':
                # Process donor form
                name = request.form.get('name', '').strip()
                email = request.form.get('email', '').strip()
                phone = request.form.get('phone', '').strip()
                blood_type = request.form.get('blood_type', '').strip()
                address = request.form.get('address', '').strip()
                last_donation = request.form.get('last_donation', '').strip()
                
                if not all([name, email, phone, blood_type, address]):
                    flash('All required fields must be filled', 'error')
                    return redirect(url_for('appointment'))
                
                db.execute(
                    'INSERT INTO donors (name, email, phone, blood_type, address, last_donation_date) VALUES (?, ?, ?, ?, ?, ?)',
                    (name, email, phone, blood_type, address, last_donation or None)
                )
                flash('Your donor application has been submitted successfully!', 'success')
            
            elif form_type == 'volunteer':
                # Process volunteer form
                name = request.form.get('name', '').strip()
                email = request.form.get('email', '').strip()
                phone = request.form.get('phone', '').strip()
                skills = request.form.get('skills', '').strip()
                availability = request.form.get('availability', '').strip()
                
                if not all([name, email, phone, availability]):
                    flash('All required fields must be filled', 'error')
                    return redirect(url_for('appointment'))
                
                db.execute(
                    'INSERT INTO volunteers (name, email, phone, skills, availability) VALUES (?, ?, ?, ?, ?)',
                    (name, email, phone, skills, availability)
                )
                flash('Your volunteer application has been submitted successfully!', 'success')
            
            elif form_type == 'request':
                # Process blood request form
                patient_name = request.form.get('patient_name', '').strip()
                hospital = request.form.get('hospital', '').strip()
                blood_type = request.form.get('blood_type', '').strip()
                units = request.form.get('units', '1').strip()
                urgency = request.form.get('urgency', 'normal').strip()
                contact_name = request.form.get('contact_name', '').strip()
                contact_phone = request.form.get('contact_phone', '').strip()
                contact_email = request.form.get('contact_email', '').strip()
                
                if not all([patient_name, hospital, blood_type, units, contact_name, contact_phone, contact_email]):
                    flash('All required fields must be filled', 'error')
                    return redirect(url_for('appointment'))
                
                try:
                    units = int(units)
                except ValueError:
                    units = 1
                
                db.execute(
                    'INSERT INTO blood_requests (patient_name, hospital, blood_type, units, urgency, contact_name, contact_phone, contact_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    (patient_name, hospital, blood_type, units, urgency, contact_name, contact_phone, contact_email)
                )
                
                # Send email notification
                email_body = (
                    f"Patient: {patient_name}\nHospital: {hospital}\n"
                    f"Blood Type: {blood_type}\nUnits Needed: {units}\n"
                    f"Urgency: {urgency}\nContact: {contact_name} "
                    f"({contact_phone}, {contact_email})"
                )
                send_email(
                    f"New Blood Request: {blood_type} needed ({urgency})",
                    app.config['MAIL_DEFAULT_SENDER'],
                    email_body
                )
                
                flash('Your blood request has been submitted successfully!', 'success')
            
            db.commit()
        except Exception as e:
            db.rollback()
            app.logger.error(f"Error processing appointment form: {str(e)}")
            flash('An error occurred while processing your request', 'error')
        finally:
            db.close()
        
        return redirect(url_for('appointment'))
    
    return render_template('appointment.html')

# Admin routes
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        if not username or not password:
            flash('Username and password are required', 'error')
            return redirect(url_for('admin_login'))
        
        try:
            db = get_db()
            admin = db.execute(
                'SELECT * FROM admin WHERE username = ?', (username,)
            ).fetchone()
            
            if admin and check_password_hash(admin['password'], password):
                session['admin_logged_in'] = True
                session['admin_username'] = admin['username']
                flash('Logged in successfully', 'success')
                return redirect(url_for('admin_dashboard'))
            else:
                flash('Invalid username or password', 'error')
        except Exception as e:
            app.logger.error(f"Login error: {str(e)}")
            flash('An error occurred during login', 'error')
        finally:
            db.close()
    
    return render_template('admin/login.html')

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    try:
        db = get_db()
        
        # Get counts for dashboard
        counts = db.execute('''
            SELECT 
                (SELECT COUNT(*) FROM donors) as donor_count,
                (SELECT COUNT(*) FROM volunteers) as volunteer_count,
                (SELECT COUNT(*) FROM blood_requests) as request_count,
                (SELECT COUNT(*) FROM messages WHERE status = 'unread') as unread_message_count
        ''').fetchone()
        
        # Get recent requests
        recent_requests = db.execute('''
            SELECT * FROM blood_requests 
            ORDER BY created_at DESC 
            LIMIT 5
        ''').fetchall()
        
        return render_template('admin/dashboard.html',
                            donor_count=counts['donor_count'],
                            volunteer_count=counts['volunteer_count'],
                            request_count=counts['request_count'],
                            message_count=counts['unread_message_count'],
                            recent_requests=recent_requests)
    except Exception as e:
        app.logger.error(f"Dashboard error: {str(e)}")
        flash('Error loading dashboard', 'error')
        return redirect(url_for('admin_login'))
    finally:
        db.close()

@app.route('/admin/donors')
@admin_required
def admin_donors():
    try:
        db = get_db()
        donors = db.execute('''
            SELECT * FROM donors 
            ORDER BY created_at DESC
        ''').fetchall()
        return render_template('admin/donors.html', donors=donors)
    except Exception as e:
        app.logger.error(f"Error fetching donors: {str(e)}")
        flash('Error loading donors', 'error')
        return redirect(url_for('admin_dashboard'))
    finally:
        db.close()

@app.route('/admin/volunteers')
@admin_required
def admin_volunteers():
    try:
        db = get_db()
        volunteers = db.execute('''
            SELECT * FROM volunteers 
            ORDER BY created_at DESC
        ''').fetchall()
        return render_template('admin/volunteers.html', volunteers=volunteers)
    except Exception as e:
        app.logger.error(f"Error fetching volunteers: {str(e)}")
        flash('Error loading volunteers', 'error')
        return redirect(url_for('admin_dashboard'))
    finally:
        db.close()

@app.route('/admin/requests')
@admin_required
def admin_requests():
    try:
        db = get_db()
        requests = db.execute('''
            SELECT * FROM blood_requests 
            ORDER BY created_at DESC
        ''').fetchall()
        return render_template('admin/requests.html', requests=requests)
    except Exception as e:
        app.logger.error(f"Error fetching requests: {str(e)}")
        flash('Error loading requests', 'error')
        return redirect(url_for('admin_dashboard'))
    finally:
        db.close()

@app.route('/admin/messages')
@admin_required
def admin_messages():
    try:
        db = get_db()
        messages = db.execute('''
            SELECT * FROM messages 
            ORDER BY created_at DESC
        ''').fetchall()
        return render_template('admin/messages.html', messages=messages)
    except Exception as e:
        app.logger.error(f"Error fetching messages: {str(e)}")
        flash('Error loading messages', 'error')
        return redirect(url_for('admin_dashboard'))
    finally:
        db.close()

@app.route('/admin/approve/<table>/<int:id>')
@admin_required
def admin_approve(table, id):
    if table not in ['donors', 'volunteers', 'blood_requests']:
        flash('Invalid table specified', 'error')
        return redirect(url_for('admin_dashboard'))
    
    try:
        db = get_db()
        db.execute(f'UPDATE {table} SET status = ? WHERE id = ?', ('approved', id))
        
        # If approving a donor, you might want to add them to inventory
        if table == 'donors':
            donor = db.execute('SELECT blood_type FROM donors WHERE id = ?', (id,)).fetchone()
            if donor:
                db.execute('''
                    INSERT OR REPLACE INTO blood_inventory (blood_type, units_available)
                    VALUES (?, COALESCE((SELECT units_available FROM blood_inventory WHERE blood_type = ?), 0) + 1)
                ''', (donor['blood_type'], donor['blood_type']))
        
        db.commit()
        flash('Application approved successfully!', 'success')
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error approving {table} {id}: {str(e)}")
        flash(f'Error approving application', 'error')
    finally:
        db.close()
    
    return redirect(url_for(f'admin_{table}'))

@app.route('/admin/reject/<table>/<int:id>')
@admin_required
def admin_reject(table, id):
    if table not in ['donors', 'volunteers', 'blood_requests']:
        flash('Invalid table specified', 'error')
        return redirect(url_for('admin_dashboard'))
    
    try:
        db = get_db()
        db.execute(f'UPDATE {table} SET status = ? WHERE id = ?', ('rejected', id))
        db.commit()
        flash('Application rejected successfully!', 'success')
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error rejecting {table} {id}: {str(e)}")
        flash(f'Error rejecting application', 'error')
    finally:
        db.close()
    
    return redirect(url_for(f'admin_{table}'))

@app.route('/admin/delete/<table>/<int:id>')
@admin_required
def admin_delete(table, id):
    if table not in ['donors', 'volunteers', 'blood_requests', 'messages']:
        flash('Invalid table specified', 'error')
        return redirect(url_for('admin_dashboard'))
    
    try:
        db = get_db()
        db.execute(f'DELETE FROM {table} WHERE id = ?', (id,))
        db.commit()
        flash('Record deleted successfully!', 'success')
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error deleting from {table} {id}: {str(e)}")
        flash('Error deleting record', 'error')
    finally:
        db.close()
    
    return redirect(url_for(f'admin_{table}'))

@app.route('/admin/logout')
@admin_required
def admin_logout():
    session.clear()
    flash('You have been logged out', 'success')
    return redirect(url_for('admin_login'))

if __name__ == '__main__':
    # Delete existing database file if it exists to ensure clean initialization
    if os.path.exists(DATABASE):
        os.remove(DATABASE)
    init_db()
    app.run(debug=True)